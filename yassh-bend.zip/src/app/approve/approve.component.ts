import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-approve',
    templateUrl: './approve.component.html',
    styleUrls: ['./approve.component.scss'],
    standalone: false
})
export class ApproveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
