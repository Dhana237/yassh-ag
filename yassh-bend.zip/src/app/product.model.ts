export interface Product {
    id: number;
    name: string;
    img: string;
    relimg1: string;
    protxt1: string;
    relimg2: string;
    protxt2: string;
    relimg3: string;
    protxt3: string;
    heading: string;
    details: string;
    explanation: string;
    backcon1: string;

}