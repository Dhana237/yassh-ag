export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyBaOiWBiDdpcA9Eb97GBIe3SJrj_yKUh3A",
    authDomain: "yassh-pharma.firebaseapp.com",
    projectId: "yassh-pharma",
    storageBucket: "yassh-pharma.firebasestorage.app",
    messagingSenderId: "700089433286",
    appId: "1:700089433286:web:d8187b474f9beefae72bc7",
    measurementId: "G-TYRJG33QLX"
  }
};
