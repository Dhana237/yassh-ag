import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-ULYJZCS7.js";
import "./chunk-S5MGYI6Y.js";
import "./chunk-47OK3O7N.js";
import "./chunk-2PLMSQS5.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-RXHGX2UO.js";
import "./chunk-YSN7JSTZ.js";
import "./chunk-P4UHYYRR.js";
import "./chunk-IGY35UNU.js";
import "./chunk-IYEYSCYL.js";
import "./chunk-DZ7BV6I4.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
