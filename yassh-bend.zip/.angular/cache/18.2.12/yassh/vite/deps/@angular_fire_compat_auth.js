import {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
} from "./chunk-MFW3FK7M.js";
import "./chunk-7WWKB3WZ.js";
import "./chunk-V56UJ5JQ.js";
import "./chunk-LWBU6SFC.js";
import "./chunk-2PLMSQS5.js";
import "./chunk-RXHGX2UO.js";
import "./chunk-YSN7JSTZ.js";
import "./chunk-P4UHYYRR.js";
import "./chunk-IGY35UNU.js";
import "./chunk-IYEYSCYL.js";
import "./chunk-DZ7BV6I4.js";
export {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
};
//# sourceMappingURL=@angular_fire_compat_auth.js.map
