import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-V56UJ5JQ.js";
import "./chunk-LWBU6SFC.js";
import "./chunk-RXHGX2UO.js";
import "./chunk-YSN7JSTZ.js";
import "./chunk-P4UHYYRR.js";
import "./chunk-IGY35UNU.js";
import "./chunk-IYEYSCYL.js";
import "./chunk-DZ7BV6I4.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
//# sourceMappingURL=@angular_fire_compat.js.map
